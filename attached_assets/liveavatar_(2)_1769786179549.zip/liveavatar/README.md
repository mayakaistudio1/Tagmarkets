# LiveAvatar (HeyGen) Integration Template

Шаблон для интеграции живого видео-аватара HeyGen в ваш проект.

## Файлы

| Файл | Описание |
|------|----------|
| `server-routes.ts` | Серверные роуты Express для API LiveAvatar |
| `client-component.tsx` | React компонент для видео-чата с аватаром |
| `env.example` | Пример переменных окружения |

## Быстрый старт

### 1. Скопируйте файлы

```bash
# Серверная часть
cp templates/liveavatar/server-routes.ts server/integrations/liveavatar.ts

# Клиентская часть
cp templates/liveavatar/client-component.tsx client/src/components/LiveAvatar.tsx
```

### 2. Установите зависимости

```bash
npm install livekit-client
```

### 3. Настройте переменные окружения

Скопируйте `env.example` и заполните ваши данные из HeyGen Dashboard:

```env
LIVEAVATAR_API_KEY=ваш_ключ
LIVEAVATAR_AVATAR_ID=id_аватара
LIVEAVATAR_VOICE_ID=id_голоса
LIVEAVATAR_CONTEXT_ID=id_базы_знаний
```

### 4. Подключите роуты к Express

```typescript
import express from 'express';
import { registerLiveAvatarRoutes } from './integrations/liveavatar';

const app = express();
app.use(express.json());

registerLiveAvatarRoutes(app);

app.listen(5000);
```

### 5. Используйте компонент в React

```tsx
import LiveAvatarChat from './components/LiveAvatar';

function App() {
  const handleSessionEnd = (messages) => {
    console.log('Session ended with messages:', messages);
    // Сохраните messages в базу данных
  };

  return (
    <LiveAvatarChat 
      language="ru" 
      onSessionEnd={handleSessionEnd}
    />
  );
}
```

## Архитектура

### LiveKit участники

В комнате LiveKit 3 участника:

1. **client** - пользователь (вы)
2. **heygen** - видео и аудио аватара
3. **agent-*** - AI бэкенд для обработки

### Управление микрофоном

Микрофон пользователя автоматически:
- **Включается** когда аватар замолкает
- **Выключается** когда аватар говорит

Это реализовано через:
1. `DataReceived` события (основной механизм)
2. `ActiveSpeakersChanged` события (резервный механизм)

### События транскрипции

Транскрипция приходит через `DataReceived`:
- `avatar.transcription` - речь аватара
- `user.transcription` - речь пользователя

## API Endpoints

| Метод | Endpoint | Описание |
|-------|----------|----------|
| POST | `/api/liveavatar/token` | Получить токен сессии |
| POST | `/api/liveavatar/start` | Начать сессию |
| POST | `/api/liveavatar/stop` | Остановить сессию |
| POST | `/api/liveavatar/event` | Отправить событие |
| GET | `/api/liveavatar/transcript/:id` | Получить транскрипт |
| POST | `/api/liveavatar/sessions/:id/end` | Завершить сессию |

## Важные моменты

1. **roomRef после connect** - устанавливать `roomRef.current = room` нужно ПОСЛЕ `room.connect()`, иначе возможны проблемы с обработчиками событий.

2. **Микрофон изначально выключен** - аватар говорит первым, поэтому микрофон изначально muted.

3. **playsinline для iOS** - атрибут `playsinline` обязателен для аудио элементов на iOS.

4. **Autoplay политика** - браузеры могут блокировать автовоспроизведение аудио. Обработайте это gracefully.

## Кастомизация

### Изменение языка

```tsx
<LiveAvatarChat language="de" />
```

### Изменение аватара

Измените `LIVEAVATAR_AVATAR_ID` в переменных окружения.

### Изменение голоса

Измените `LIVEAVATAR_VOICE_ID` в переменных окружения.

### Изменение базы знаний

Измените `LIVEAVATAR_CONTEXT_ID` в переменных окружения.

## Проверенные проекты

Этот шаблон протестирован и работает в 10+ проектах. Если что-то не работает - проверьте:

1. Переменные окружения настроены правильно
2. livekit-client установлен
3. roomRef устанавливается после connect
4. Обработчики событий подписаны до connect
