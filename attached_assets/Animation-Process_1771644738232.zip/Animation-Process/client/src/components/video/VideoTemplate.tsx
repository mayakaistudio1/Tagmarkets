// Video Template - Jet-Up AI Partner Program

import { AnimatePresence } from 'framer-motion';
import { useVideoPlayer } from '@/lib/video';
import { IntroScene } from './video_scenes/IntroScene';
import { ToolkitScene } from './video_scenes/ToolkitScene';
import { IncomeSourcesScene } from './video_scenes/IncomeSourcesScene';
import { LotCommissionScene } from './video_scenes/LotCommissionScene';
import { ProfitShareScene } from './video_scenes/ProfitShareScene';
import { InfinityBonusScene } from './video_scenes/InfinityBonusScene';
import { LifestyleScene } from './video_scenes/LifestyleScene';
import { OutroScene } from './video_scenes/OutroScene';

const SCENE_DURATIONS = {
  intro: 4000,
  toolkit: 5000,
  income: 4000,
  lotCommission: 6000,
  profitShare: 5000,
  infinityBonus: 6000,
  lifestyle: 5000,
  outro: 5000,
};

export default function VideoTemplate() {
  const { currentScene } = useVideoPlayer({
    durations: SCENE_DURATIONS,
  });

  return (
    <div
      className="w-full h-screen overflow-hidden relative"
      style={{ backgroundColor: 'var(--color-bg-dark)' }}
    >
      <AnimatePresence mode="wait">
        {currentScene === 0 && <IntroScene key="intro" />}
        {currentScene === 1 && <ToolkitScene key="toolkit" />}
        {currentScene === 2 && <IncomeSourcesScene key="income" />}
        {currentScene === 3 && <LotCommissionScene key="lotCommission" />}
        {currentScene === 4 && <ProfitShareScene key="profitShare" />}
        {currentScene === 5 && <InfinityBonusScene key="infinityBonus" />}
        {currentScene === 6 && <LifestyleScene key="lifestyle" />}
        {currentScene === 7 && <OutroScene key="outro" />}
      </AnimatePresence>
    </div>
  );
}
