import { motion } from 'framer-motion';
import { sceneTransitions, containerVariants, itemVariants } from '@/lib/video';
import { Watch, Home, Plane } from 'lucide-react';

const rewards = [
  { icon: Watch, label: "Luxury Watches" },
  { icon: Plane, label: "Exclusive Travel" },
  { icon: Home, label: "Real Estate" },
];

export const LifestyleScene = () => {
  return (
    <motion.div
      className="absolute inset-0 flex flex-col items-center justify-center bg-bg-dark text-text-primary p-12"
      key="lifestyle"
      {...sceneTransitions.crossDissolve}
    >
      <div className="absolute inset-0 bg-gradient-to-t from-orange-900/20 to-transparent pointer-events-none" />

      <motion.h2 
        className="text-6xl font-display font-bold mb-20 text-center"
        initial={{ opacity: 0, y: -20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.2 }}
      >
        Global Pools & <span className="text-orange-400">Lifestyle</span>
      </motion.h2>

      <motion.div 
        className="flex gap-12 w-full max-w-6xl justify-center"
        variants={containerVariants}
        initial="hidden"
        animate="visible"
      >
        {rewards.map((item, index) => (
          <motion.div 
            key={index}
            variants={itemVariants}
            className="flex flex-col items-center justify-center w-64 h-64 rounded-3xl bg-white/5 border border-white/10 backdrop-blur-md relative overflow-hidden group"
          >
            <div className="absolute inset-0 bg-orange-500/10 opacity-0 group-hover:opacity-100 transition-opacity duration-500" />
            <item.icon size={80} className="text-white mb-6 drop-shadow-lg" />
            <h3 className="text-2xl font-bold text-center">{item.label}</h3>
          </motion.div>
        ))}
      </motion.div>
    </motion.div>
  );
};
