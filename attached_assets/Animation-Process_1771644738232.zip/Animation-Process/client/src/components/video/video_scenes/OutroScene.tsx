import { motion } from 'framer-motion';
import { sceneTransitions, elementAnimations } from '@/lib/video';
import { ArrowRight, Globe } from 'lucide-react';

export const OutroScene = () => {
  return (
    <motion.div
      className="absolute inset-0 flex flex-col items-center justify-center bg-bg-dark text-text-primary p-12 overflow-hidden"
      key="outro"
      {...sceneTransitions.fadeBlur}
    >
      <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_center,_var(--color-accent)_0%,_transparent_60%)] opacity-20 blur-3xl" />

      <motion.div className="relative z-10 flex flex-col items-center text-center">
        <motion.h2 
          className="text-6xl md:text-8xl font-display font-bold mb-8 text-white"
          initial={{ opacity: 0, scale: 0.9 }}
          animate={{ opacity: 1, scale: 1 }}
          transition={{ duration: 0.8 }}
        >
          Join Jet-Up AI
        </motion.h2>

        <motion.div 
          className="flex items-center gap-4 text-2xl md:text-3xl text-accent font-medium mb-12"
          variants={elementAnimations.fadeUp}
          initial="initial"
          animate="animate"
        >
          <Globe size={32} />
          <span>jet-up.ai/partner</span>
        </motion.div>

        <motion.div
          className="bg-white text-bg-dark px-8 py-4 rounded-full text-2xl font-bold flex items-center gap-3 shadow-[0_0_30px_rgba(255,255,255,0.3)]"
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.5, type: "spring" }}
        >
          Start Earning Today <ArrowRight />
        </motion.div>
      </motion.div>
    </motion.div>
  );
};
