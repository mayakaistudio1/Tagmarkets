import { motion } from 'framer-motion';
import { sceneTransitions, containerVariants, itemVariants } from '@/lib/video';
import { PieChart, TrendingUp, Infinity as InfinityIcon, Globe } from 'lucide-react';

const sources = [
  { icon: PieChart, title: "Lot-Provisionen", color: "text-blue-400" },
  { icon: TrendingUp, title: "Profit Share", color: "text-green-400" },
  { icon: InfinityIcon, title: "Infinity Bonus", color: "text-purple-400" },
  { icon: Globe, title: "Global Pools", color: "text-orange-400" },
];

export const IncomeSourcesScene = () => {
  return (
    <motion.div
      className="absolute inset-0 flex flex-col items-center justify-center bg-bg-dark text-text-primary p-12"
      key="income"
      {...sceneTransitions.zoomThrough}
    >
      <motion.h2 
        initial={{ opacity: 0, scale: 0.9 }}
        animate={{ opacity: 1, scale: 1 }}
        transition={{ duration: 0.5 }}
        className="text-6xl font-display font-bold mb-20 text-center"
      >
        4 Income Streams
      </motion.h2>
      
      <motion.div 
        className="grid grid-cols-2 gap-12 w-full max-w-5xl"
        variants={containerVariants}
        initial="hidden"
        animate="visible"
      >
        {sources.map((item, index) => (
          <motion.div 
            key={index}
            variants={itemVariants}
            className="flex items-center gap-6 p-8 rounded-2xl bg-gradient-to-r from-white/5 to-transparent border-l-4 border-l-accent"
          >
            <item.icon size={56} className={`${item.color} drop-shadow-lg`} />
            <h3 className="text-4xl font-bold">{item.title}</h3>
          </motion.div>
        ))}
      </motion.div>
    </motion.div>
  );
};
