import { motion } from 'framer-motion';
import { sceneTransitions } from '@/lib/video';
import { BarChart3 } from 'lucide-react';

export const LotCommissionScene = () => {
  return (
    <motion.div
      className="absolute inset-0 flex flex-col items-center justify-center bg-bg-dark text-text-primary p-12 overflow-hidden"
      key="lot"
      {...sceneTransitions.slideUp}
    >
      <div className="absolute inset-0 grid grid-cols-[repeat(20,minmax(0,1fr))] opacity-10">
        {Array.from({ length: 400 }).map((_, i) => (
          <div key={i} className="border border-white/10 aspect-square" />
        ))}
      </div>

      <div className="relative z-10 w-full max-w-6xl flex items-center justify-between gap-12">
        <div className="flex-1">
          <motion.div 
            initial={{ opacity: 0, x: -50 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.8 }}
          >
            <h2 className="text-6xl font-display font-bold mb-6 text-blue-400">Lot-Provisionen</h2>
            <p className="text-3xl text-text-secondary leading-relaxed">
              Earn on every traded lot within your entire team structure.
            </p>
          </motion.div>
        </div>
        
        <motion.div 
          className="flex-1 h-[400px] flex items-end justify-center gap-4 bg-white/5 p-8 rounded-3xl border border-white/10 backdrop-blur-md relative"
          initial={{ opacity: 0, y: 50 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.3 }}
        >
          <BarChart3 className="absolute top-6 right-6 text-white/20" size={40} />
          {[30, 45, 60, 40, 75, 55, 90].map((h, i) => (
            <motion.div
              key={i}
              className="w-12 bg-gradient-to-t from-blue-600 to-blue-400 rounded-t-lg shadow-[0_0_20px_rgba(59,130,246,0.3)]"
              initial={{ height: 0 }}
              animate={{ height: `${h}%` }}
              transition={{ delay: 0.5 + i * 0.1, duration: 1, type: "spring" }}
            />
          ))}
          <div className="absolute bottom-8 left-0 right-0 h-px bg-white/20" />
        </motion.div>
      </div>
    </motion.div>
  );
};
