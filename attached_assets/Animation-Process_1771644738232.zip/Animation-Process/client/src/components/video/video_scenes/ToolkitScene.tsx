import { motion } from 'framer-motion';
import { sceneTransitions, containerVariants, itemVariants } from '@/lib/video';
import { Wrench, GraduationCap, BrainCircuit } from 'lucide-react';

const tools = [
  { icon: Wrench, title: "Tools", desc: "Professional Marketing Assets" },
  { icon: GraduationCap, title: "Schulung", desc: "Expert Training & Guides" },
  { icon: BrainCircuit, title: "AI-Power", desc: "Smart Automation & Analytics" },
];

export const ToolkitScene = () => {
  return (
    <motion.div
      className="absolute inset-0 flex flex-col items-center justify-center bg-bg-dark text-text-primary p-12"
      key="toolkit"
      {...sceneTransitions.slideLeft}
    >
      <div className="absolute top-0 left-0 w-full h-1/2 bg-gradient-to-b from-blue-900/20 to-transparent pointer-events-none" />
      
      <motion.h2 
        initial={{ opacity: 0, y: -20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.2 }}
        className="text-5xl font-display font-bold mb-16 text-center"
      >
        Your <span className="text-accent">Partner Toolkit</span>
      </motion.h2>
      
      <motion.div 
        className="grid grid-cols-1 md:grid-cols-3 gap-8 w-full max-w-6xl"
        variants={containerVariants}
        initial="hidden"
        animate="visible"
      >
        {tools.map((item, index) => (
          <motion.div 
            key={index}
            variants={itemVariants}
            className="flex flex-col items-center p-8 rounded-2xl bg-white/5 border border-white/10 backdrop-blur-sm shadow-xl"
          >
            <div className="p-4 rounded-full bg-accent/10 mb-6 relative group">
              <div className="absolute inset-0 bg-accent/20 blur-xl rounded-full opacity-0 group-hover:opacity-100 transition-opacity" />
              <item.icon size={48} className="text-accent relative z-10" />
            </div>
            <h3 className="text-3xl font-bold mb-3">{item.title}</h3>
            <p className="text-text-secondary text-center text-xl">{item.desc}</p>
          </motion.div>
        ))}
      </motion.div>
    </motion.div>
  );
};
