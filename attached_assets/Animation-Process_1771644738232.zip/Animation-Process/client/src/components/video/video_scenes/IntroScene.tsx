import { motion } from 'framer-motion';
import { sceneTransitions, elementAnimations } from '@/lib/video';
import { Rocket } from 'lucide-react';

export const IntroScene = () => {
  return (
    <motion.div
      className="absolute inset-0 flex flex-col items-center justify-center bg-bg-dark text-text-primary overflow-hidden"
      key="intro"
      {...sceneTransitions.fadeBlur}
    >
      <div className="absolute inset-0 bg-[radial-gradient(circle_at_center,_var(--color-accent)_0%,_transparent_70%)] opacity-20 blur-3xl" />
      
      <motion.div 
        className="relative z-10 flex flex-col items-center"
        initial="hidden"
        animate="visible"
        variants={{
          visible: { transition: { staggerChildren: 0.2 } }
        }}
      >
        <motion.div variants={elementAnimations.popIn} className="mb-8 p-6 rounded-3xl bg-white/5 backdrop-blur-lg border border-white/10 shadow-[0_0_50px_-12px_var(--color-accent)]">
          <Rocket size={80} className="text-accent drop-shadow-[0_0_15px_var(--color-accent)]" />
        </motion.div>
        
        <motion.h1 
          variants={elementAnimations.fadeUp}
          className="text-6xl md:text-8xl font-display font-bold tracking-tight text-center bg-gradient-to-r from-white via-blue-200 to-blue-400 bg-clip-text text-transparent drop-shadow-sm"
        >
          JET-UP AI
        </motion.h1>
        
        <motion.div 
          variants={elementAnimations.fadeUp}
          className="mt-4 text-2xl md:text-3xl text-text-secondary font-light tracking-wide text-center uppercase"
        >
          Partner Program
        </motion.div>
      </motion.div>
    </motion.div>
  );
};
