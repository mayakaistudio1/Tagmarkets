import { motion } from 'framer-motion';
import { sceneTransitions } from '@/lib/video';
import { Infinity as InfinityIcon } from 'lucide-react';

export const InfinityBonusScene = () => {
  return (
    <motion.div
      className="absolute inset-0 flex flex-col items-center justify-center bg-bg-dark text-text-primary p-12 overflow-hidden"
      key="infinity"
      {...sceneTransitions.perspectiveFlip}
    >
      <div className="absolute inset-0 flex items-center justify-center opacity-10 pointer-events-none">
        <InfinityIcon size={800} strokeWidth={0.5} className="text-purple-500 animate-pulse" />
      </div>

      <motion.div className="relative z-10 text-center">
        <motion.h2 
          className="text-7xl font-display font-bold mb-12 text-purple-400 drop-shadow-[0_0_20px_rgba(168,85,247,0.5)]"
          initial={{ opacity: 0, scale: 0.8 }}
          animate={{ opacity: 1, scale: 1 }}
          transition={{ duration: 0.8 }}
        >
          Infinity Bonus
        </motion.h2>

        <div className="flex gap-8 items-end h-[300px]">
          {[5, 10, 15, 20, 25].map((val, i) => (
            <motion.div
              key={i}
              className="flex flex-col items-center gap-4"
              initial={{ opacity: 0, y: 50 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.3 + i * 0.15 }}
            >
              <div className="text-2xl font-bold text-white">{val}%</div>
              <div 
                className="w-24 bg-gradient-to-t from-purple-900 to-purple-500 rounded-t-xl"
                style={{ height: `${val * 10}px` }}
              />
              <div className="text-sm text-text-secondary uppercase">Rank {i + 1}</div>
            </motion.div>
          ))}
        </div>
        
        <motion.p 
          className="mt-12 text-2xl text-text-muted max-w-2xl mx-auto"
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 1.2 }}
        >
          Earn extra percentages as your team volume grows infinitely deep.
        </motion.p>
      </motion.div>
    </motion.div>
  );
};
