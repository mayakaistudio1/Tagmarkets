/**
 * LiveAvatar (HeyGen) Integration - React Client Component Template
 * 
 * This template provides a complete React component for LiveAvatar video chat.
 * Uses LiveKit for WebRTC connection.
 * 
 * Required npm packages:
 * - livekit-client
 * 
 * Key Architecture:
 * - 3 LiveKit participants: "client" (user), "heygen" (avatar), "agent-*" (AI backend)
 * - Microphone control via DataReceived events (primary) and ActiveSpeakersChanged (backup)
 * - Real-time transcription via DataReceived events
 */

import { useState, useEffect, useRef, useCallback } from 'react';
import { 
  Room, 
  RoomEvent, 
  Track, 
  RemoteTrack, 
  RemoteTrackPublication, 
  RemoteParticipant, 
  Participant, 
  ConnectionState 
} from 'livekit-client';

interface TranscriptMessage {
  sender: string;
  text: string;
  timestamp: number;
  startMs?: number;
}

interface LiveAvatarProps {
  language?: string;
  onSessionEnd?: (messages: TranscriptMessage[]) => void;
}

export default function LiveAvatarChat({ language = "ru", onSessionEnd }: LiveAvatarProps) {
  const [status, setStatus] = useState<'idle' | 'connecting' | 'active' | 'finished'>('idle');
  const [messages, setMessages] = useState<TranscriptMessage[]>([]);
  const [sessionId, setSessionId] = useState<string | null>(null);
  const [sessionToken, setSessionToken] = useState<string | null>(null);
  const [isMuted, setIsMuted] = useState(true);
  const [isAvatarTalking, setIsAvatarTalking] = useState(false);
  const [error, setError] = useState<string | null>(null);
  
  const videoRef = useRef<HTMLVideoElement>(null);
  const audioContainerRef = useRef<HTMLDivElement>(null);
  const audioElementsRef = useRef<Map<string, HTMLAudioElement>>(new Map());
  const roomRef = useRef<Room | null>(null);
  
  const sessionStartTimeRef = useRef<number>(0);
  const messagesRef = useRef<TranscriptMessage[]>([]);

  // Handle track subscribed
  const handleTrackSubscribed = useCallback(
    (track: RemoteTrack, publication: RemoteTrackPublication, participant: RemoteParticipant) => {
      console.log("Track subscribed:", track.kind, "from:", participant.identity);

      if (track.kind === Track.Kind.Video && videoRef.current) {
        track.attach(videoRef.current);
        console.log("Video track attached");
      } else if (track.kind === Track.Kind.Audio && audioContainerRef.current) {
        const trackId = `${participant.identity}-${track.sid}`;

        let audioEl = audioElementsRef.current.get(trackId);
        if (!audioEl) {
          audioEl = document.createElement("audio");
          audioEl.autoplay = true;
          audioEl.setAttribute("playsinline", "true");
          audioEl.id = trackId;
          audioContainerRef.current.appendChild(audioEl);
          audioElementsRef.current.set(trackId, audioEl);
        }

        track.attach(audioEl);
        audioEl.play().catch(err => console.log("Audio autoplay blocked:", err.message));
      }
    },
    []
  );

  // Handle track unsubscribed
  const handleTrackUnsubscribed = useCallback(
    (track: RemoteTrack, publication?: RemoteTrackPublication, participant?: RemoteParticipant) => {
      track.detach();
      console.log("Track unsubscribed:", track.kind);

      if (track.kind === Track.Kind.Audio && participant && track.sid) {
        const trackId = `${participant.identity}-${track.sid}`;
        const audioEl = audioElementsRef.current.get(trackId);
        if (audioEl) {
          audioEl.remove();
          audioElementsRef.current.delete(trackId);
        }
      }
    },
    []
  );

  // Handle participant connected
  const handleParticipantConnected = useCallback((participant: RemoteParticipant) => {
    console.log("Participant connected:", participant.identity);

    participant.trackPublications.forEach((publication) => {
      if (publication.track && publication.isSubscribed) {
        if (publication.track.kind === Track.Kind.Video && videoRef.current) {
          publication.track.attach(videoRef.current);
        } else if (publication.track.kind === Track.Kind.Audio && audioContainerRef.current) {
          const track = publication.track;
          const trackId = `${participant.identity}-${track.sid}`;

          let audioEl = audioElementsRef.current.get(trackId);
          if (!audioEl) {
            audioEl = document.createElement("audio");
            audioEl.autoplay = true;
            audioEl.setAttribute("playsinline", "true");
            audioEl.id = trackId;
            audioContainerRef.current.appendChild(audioEl);
            audioElementsRef.current.set(trackId, audioEl);
          }

          track.attach(audioEl);
          audioEl.play().catch(err => console.log("Audio autoplay blocked:", err.message));
        }
      }
    });
  }, []);

  // Handle disconnected
  const handleDisconnected = useCallback(() => {
    console.log("Room disconnected");
  }, []);

  // Handle connection state changed
  const handleConnectionStateChanged = useCallback((state: ConnectionState) => {
    console.log("Connection state changed:", state);
    if (state === ConnectionState.Disconnected) {
      console.log("Connection lost");
    }
  }, []);

  // Handle active speakers changed - mic control
  const handleActiveSpeakersChanged = useCallback(
    (speakers: Participant[]) => {
      if (!roomRef.current) return;

      const localIdentity = roomRef.current.localParticipant.identity;
      const avatarIsSpeaking = speakers.some(
        (speaker) => speaker.identity !== localIdentity
      );

      console.log("Active speakers changed, avatar speaking:", avatarIsSpeaking);

      setIsAvatarTalking((prevTalking) => {
        if (avatarIsSpeaking && !prevTalking) {
          console.log("Avatar started speaking - muting user mic");
          roomRef.current?.localParticipant.setMicrophoneEnabled(false);
          setIsMuted(true);
          return true;
        } else if (!avatarIsSpeaking && prevTalking) {
          console.log("Avatar stopped speaking - unmuting user mic");
          roomRef.current?.localParticipant.setMicrophoneEnabled(true);
          setIsMuted(false);
          return false;
        }
        return prevTalking;
      });
    },
    []
  );

  // Handle data received - PRIMARY mic control and transcription
  const handleDataReceived = useCallback(
    (payload: Uint8Array, participant?: RemoteParticipant) => {
      try {
        const message = new TextDecoder().decode(payload);
        console.log("Data received:", message, "from:", participant?.identity);
        
        const data = JSON.parse(message);
        
        // Mic control via data events
        if (data.type === "avatar_start_talking" || data.type === "agent_start_talking") {
          console.log("Avatar started talking - muting user");
          setIsAvatarTalking(true);
          if (roomRef.current) {
            roomRef.current.localParticipant.setMicrophoneEnabled(false);
            setIsMuted(true);
          }
        } else if (data.type === "avatar_stop_talking" || data.type === "agent_stop_talking") {
          console.log("Avatar stopped talking - unmuting user");
          setIsAvatarTalking(false);
          if (roomRef.current) {
            roomRef.current.localParticipant.setMicrophoneEnabled(true);
            setIsMuted(false);
          }
        }
        
        // Handle transcription events
        if (data.event_type === 'avatar.transcription' && data.text) {
          const msg: TranscriptMessage = {
            sender: 'avatar',
            text: data.text,
            timestamp: Date.now(),
            startMs: Date.now() - sessionStartTimeRef.current,
          };
          messagesRef.current = [...messagesRef.current, msg];
          setMessages(prev => [...prev, msg]);
        } else if (data.event_type === 'user.transcription' && data.text) {
          const msg: TranscriptMessage = {
            sender: 'user',
            text: data.text,
            timestamp: Date.now(),
            startMs: Date.now() - sessionStartTimeRef.current,
          };
          messagesRef.current = [...messagesRef.current, msg];
          setMessages(prev => [...prev, msg]);
        }
      } catch (e) {
        console.log("Non-JSON data received");
      }
    },
    []
  );

  // Start session
  const startSession = async () => {
    setStatus('connecting');
    setError(null);
    setMessages([]);
    messagesRef.current = [];
    
    try {
      // Get token
      const tokenRes = await fetch('/api/liveavatar/token', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ language }),
      });
      
      if (!tokenRes.ok) {
        const err = await tokenRes.json();
        throw new Error(err.details || err.error || 'Failed to get session token');
      }
      
      const tokenData = await tokenRes.json();
      const { session_id, session_token } = tokenData;
      
      if (!session_id || !session_token) {
        throw new Error('Invalid token response from server');
      }
      
      setSessionId(session_id);
      setSessionToken(session_token);
      
      console.log('LiveAvatar token received:', session_id);

      // Start session
      const startRes = await fetch('/api/liveavatar/start', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ session_token }),
      });
      
      if (!startRes.ok) {
        const err = await startRes.json();
        throw new Error(err.details || err.error || 'Failed to start session');
      }
      
      const startData = await startRes.json();
      console.log('LiveAvatar session started:', startData);
      
      const { livekit_url, livekit_client_token } = startData.data || {};
      
      if (!livekit_url || !livekit_client_token) {
        throw new Error('Missing LiveKit connection data');
      }

      // Create LiveKit room
      const room = new Room({
        adaptiveStream: true,
        dynacast: true,
      });

      // Subscribe to events BEFORE connect
      room.on(RoomEvent.TrackSubscribed, handleTrackSubscribed);
      room.on(RoomEvent.TrackUnsubscribed, handleTrackUnsubscribed);
      room.on(RoomEvent.Disconnected, handleDisconnected);
      room.on(RoomEvent.ConnectionStateChanged, handleConnectionStateChanged);
      room.on(RoomEvent.ParticipantConnected, handleParticipantConnected);
      room.on(RoomEvent.DataReceived, handleDataReceived);
      room.on(RoomEvent.ActiveSpeakersChanged, handleActiveSpeakersChanged);

      await room.connect(livekit_url, livekit_client_token);
      
      // Initially mute microphone - avatar will talk first
      await room.localParticipant.setMicrophoneEnabled(false);
      setIsMuted(true);

      // Set roomRef AFTER connect
      roomRef.current = room;
      
      console.log('Connected to LiveKit room');
      
      sessionStartTimeRef.current = Date.now();
      setStatus('active');
      
    } catch (error: any) {
      console.error('Failed to start session:', error);
      setError(error.message || 'Failed to connect');
      setStatus('idle');
      cleanup();
    }
  };

  // Toggle mute
  const toggleMute = async () => {
    if (isAvatarTalking) return;
    
    if (roomRef.current) {
      const newMuted = !isMuted;
      await roomRef.current.localParticipant.setMicrophoneEnabled(!newMuted);
      setIsMuted(newMuted);
    }
  };

  // Cleanup
  const cleanup = () => {
    audioElementsRef.current.forEach((audioEl) => {
      audioEl.remove();
    });
    audioElementsRef.current.clear();
    
    if (roomRef.current) {
      roomRef.current.disconnect();
      roomRef.current = null;
    }
  };

  // Finish session
  const finishSession = async () => {
    if (status !== 'active' || !sessionId || !sessionToken) return;

    try {
      // Stop LiveAvatar session
      await fetch('/api/liveavatar/stop', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ 
          session_id: sessionId,
          session_token: sessionToken 
        }),
      });

      await fetch(`/api/liveavatar/sessions/${sessionId}/end`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ session_token: sessionToken }),
      });

      console.log('LiveAvatar session finished');
      
      // Callback with messages
      if (onSessionEnd) {
        onSessionEnd([...messagesRef.current]);
      }
      
    } catch (error) {
      console.error('Failed to finish session:', error);
    } finally {
      cleanup();
      setStatus('finished');
    }
  };

  useEffect(() => {
    return () => cleanup();
  }, []);

  return (
    <div className="live-avatar-container">
      {/* Video element for avatar */}
      <video 
        ref={videoRef}
        autoPlay
        playsInline
        muted
        style={{ 
          width: '100%', 
          height: '100%', 
          objectFit: 'cover',
          display: status === 'active' ? 'block' : 'none'
        }}
      />
      
      {/* Hidden audio container */}
      <div ref={audioContainerRef} style={{ display: 'none' }} />
      
      {/* Status indicators */}
      {status === 'idle' && (
        <button onClick={startSession}>Start Video Call</button>
      )}
      
      {status === 'connecting' && (
        <div>Connecting...</div>
      )}
      
      {status === 'active' && (
        <div className="controls">
          <button onClick={toggleMute} disabled={isAvatarTalking}>
            {isMuted ? 'Unmute' : 'Mute'}
          </button>
          <button onClick={finishSession}>End Call</button>
          {isAvatarTalking && <span>Avatar is speaking...</span>}
        </div>
      )}
      
      {status === 'finished' && (
        <div>Call ended. Thank you!</div>
      )}
      
      {error && (
        <div className="error">{error}</div>
      )}
      
      {/* Transcript */}
      <div className="transcript">
        {messages.map((msg, idx) => (
          <div key={idx} className={`message ${msg.sender}`}>
            <strong>{msg.sender}:</strong> {msg.text}
          </div>
        ))}
      </div>
    </div>
  );
}
