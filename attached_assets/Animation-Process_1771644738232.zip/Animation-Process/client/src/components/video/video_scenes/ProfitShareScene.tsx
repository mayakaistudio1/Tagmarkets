import { motion } from 'framer-motion';
import { sceneTransitions } from '@/lib/video';
import { Users, TrendingUp } from 'lucide-react';

export const ProfitShareScene = () => {
  return (
    <motion.div
      className="absolute inset-0 flex flex-col items-center justify-center bg-bg-dark text-text-primary p-12"
      key="profit"
      {...sceneTransitions.wipe}
    >
      <div className="absolute inset-0 bg-gradient-to-br from-green-900/20 to-transparent pointer-events-none" />

      <motion.div 
        className="relative z-10 flex flex-col items-center text-center"
        initial="hidden"
        animate="visible"
      >
        <motion.div 
          initial={{ scale: 0 }}
          animate={{ scale: 1 }}
          transition={{ type: "spring", stiffness: 200, damping: 20 }}
          className="mb-8 p-6 bg-green-500/10 rounded-full border border-green-500/20"
        >
          <TrendingUp size={64} className="text-green-400" />
        </motion.div>

        <motion.h2 
          className="text-7xl font-display font-bold mb-4 text-white"
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.2 }}
        >
          Profit Share
        </motion.h2>

        <motion.p 
          className="text-3xl text-green-400 font-bold mb-12 uppercase tracking-widest"
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 0.4 }}
        >
          Share in Team Success
        </motion.p>

        <div className="flex items-center gap-16">
          <motion.div 
            className="flex flex-col items-center"
            initial={{ opacity: 0, x: -30 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ delay: 0.6 }}
          >
            <div className="text-6xl font-mono font-bold text-white mb-2">50%</div>
            <div className="text-xl text-text-secondary uppercase tracking-wide">RevShare</div>
          </motion.div>

          <div className="h-24 w-px bg-white/20" />

          <motion.div 
            className="flex flex-col items-center"
            initial={{ opacity: 0, x: 30 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ delay: 0.7 }}
          >
            <Users size={48} className="text-white mb-4" />
            <div className="text-xl text-text-secondary uppercase tracking-wide">Team Volume</div>
          </motion.div>
        </div>
      </motion.div>
    </motion.div>
  );
};
